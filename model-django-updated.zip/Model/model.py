# Tratamiento de datos
# ------------------------------------------------------------------------------
import joblib
import pandas as pd
# from google.colab import files
import seaborn as sns
import matplotlib.pyplot as plt
import io
import json
import numpy as np
import os.path
from sklearn import datasets, linear_model, metrics
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn import preprocessing

# Funciones
# ------------------------------------------------------------------------------


def upload_files():
    uploaded = files.upload()
    for file_name in uploaded.keys():
        print('User uploaded file "{name}" with length {length} bytes'.format(
              name=file_name, length=len(uploaded[file_name])))
    return uploaded


def draw_hist_boxplot(df, feature_name):
    sns.boxplot(x=feature_name, data=df)
    sns.stripplot(x=feature_name, data=df, color='#474646')


def replace_outliers_with_median(df, feature_name):
    Q1 = df[feature_name].quantile(0.25)
    median = df[feature_name].quantile(0.5)
    Q3 = df[feature_name].quantile(0.75)
    IQR = Q3 - Q1
    lower_whisker = Q1 - 1.5 * IQR
    upper_whisker = Q3 + 1.5 * IQR
    df[feature_name] = np.where((df[feature_name] < lower_whisker) |
                                (df[feature_name] > upper_whisker),
                                median,
                                df[feature_name])


def columns_without_values(data):
    columns = data.isnull().sum()
    print(columns[columns > 0])


dataset = pd.read_csv('result20200307.csv', encoding='utf8')


features = list(dataset)
target = 'price'

numeric_features = dataset._get_numeric_data().columns.tolist()

categorical_features = list(set(features) - set(numeric_features))

numeric_features.remove(target)

all_features = numeric_features + categorical_features


X_train_full_nno, X_test_nno = train_test_split(dataset[numeric_features + [target]],
                                                test_size=0.1, random_state=1)
X_train_nno, X_val_nno = train_test_split(
    X_train_full_nno, test_size=0.1, random_state=1)
y_train_nno = X_train_nno[target].values
y_val_nno = X_val_nno[target].values
y_test_nno = X_test_nno[target].values
X_train_nno.drop([target, 'fuelTypeId', 'id', 'makeId', 'modelId', 'provinceId',
                 'transmissionTypeId', 'brand_id', 'model_id'], axis=1, inplace=True)
X_val_nno.drop([target, 'fuelTypeId', 'id', 'makeId', 'modelId', 'provinceId',
               'transmissionTypeId', 'brand_id', 'model_id'], axis=1, inplace=True)
X_test_nno.drop([target, 'fuelTypeId', 'id', 'makeId', 'modelId', 'provinceId',
                'transmissionTypeId', 'brand_id', 'model_id'], axis=1, inplace=True)


reg_nno = linear_model.LinearRegression()
reg_nno.fit(X_train_nno, y_train_nno)

# print(X_train_nno)

print(reg_nno.score(X_train_nno, y_train_nno))
y_predict_nno = reg_nno.predict(X_test_nno)


# save the model to disk
filename = 'finalized_model_2.sav'
joblib.dump(reg_nno, filename)

# load the model from disk
# loaded_model = joblib.load(filename)
# result = loaded_model.score(X_test_nno, y_test_nno)
# print(result)
