![Titanic-sinking](https://user-images.githubusercontent.com/59442907/97293330-89abad00-1872-11eb-8b51-2c2e93a6de33.jpg)

# Titanic Survival Predictor ML Model 
### Tells whether a passenger (with characteristics as your input) can survive the Titanic drowning or not!

The model and dataset can be found [here](https://github.com/k2maan/TitanicPredictionDjangoML/tree/master/Model%20and%20data).
Also check the competetion [Titanic: Machine learning from Disaster](https://www.kaggle.com/c/titanic) on kaggle.


## Screenshots-
![screenshot](https://user-images.githubusercontent.com/59442907/97587747-bf42c880-1a21-11eb-8d54-59730337c737.jpg)
