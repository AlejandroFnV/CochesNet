from django.contrib import admin

from .models import Tiempo

admin.site.register(Tiempo)
